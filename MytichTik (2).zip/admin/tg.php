<?php
$token ="6236976040:AAHH375YinV59UhxoUbph3LmuJZeeyir5sQ";
$chatid = "5650515424";

?>